var express = require('express');
var app = express();
app.listen(3000,(req,res) => {
    console.log('Servidor express carregado!');
});