console.log("1");
t();
console.log("2");
function t(){
    console.log("3");
}